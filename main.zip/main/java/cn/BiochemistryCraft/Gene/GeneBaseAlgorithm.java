package cn.BiochemistryCraft.Gene;


import cpw.mods.fml.common.eventhandler.Event;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent;

public class GeneBaseAlgorithm {
	
	public static void mutationProbly_normal(Entity entity,float par2,Event event){
		
		
		
		
	}
	
	
	public static void mutationProbly_player(EntityPlayer player,float par2,PlayerEvent event){
		
		
		
	}

}
