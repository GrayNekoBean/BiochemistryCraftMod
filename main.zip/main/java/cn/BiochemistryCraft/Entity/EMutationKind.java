package cn.BiochemistryCraft.Entity;

public enum EMutationKind {
	
	headCirrus,
	
	sickleArms,
	
	HugeLegs,
	
	largeArms,
	
	mutateEyes,
	
	biggerMouse,
	
	superHeal;

}
