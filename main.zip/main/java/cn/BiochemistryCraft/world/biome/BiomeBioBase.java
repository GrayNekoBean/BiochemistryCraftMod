package cn.BiochemistryCraft.world.biome;

import net.minecraft.world.biome.BiomeGenBase;

public class BiomeBioBase extends BiomeGenBase{

	public BiomeBioBase(int arg0) {
		super(arg0);
		//��û��д23333333
	}

}
