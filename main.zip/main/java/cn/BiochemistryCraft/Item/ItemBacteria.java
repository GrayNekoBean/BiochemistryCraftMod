package cn.BiochemistryCraft.Item;

import net.minecraft.item.Item;

public class ItemBacteria extends Item{

}
