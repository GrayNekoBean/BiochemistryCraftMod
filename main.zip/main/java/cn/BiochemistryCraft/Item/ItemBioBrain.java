package cn.BiochemistryCraft.Item;

public class ItemBioBrain extends BCCItemBase{
	public ItemBioBrain ()
	{
		this.setItem("BioBrain", true);
	}
}
