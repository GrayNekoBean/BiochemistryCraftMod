package cn.BiochemistryCraft.GUI;

public class GUIID {
	public static final int BioExtracter=0x7eb;
}
