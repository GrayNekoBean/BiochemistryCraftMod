package cn.BiochemistryCraft.proxy;

public class BCCcommonProxy {

	public void preInit(){
		
	}
	
	public void load(){
		
	}
	
	public void postLoad(){
		
	}
	
	public void registerRenderThings(){
	
	}
	
	public void registerSound(){
		
	}
	
	public void registerNormalThings(){
		
	}
}
