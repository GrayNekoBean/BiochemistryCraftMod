package cn.BiochemistryCraft;

import net.minecraft.util.DamageSource;

public class BCCDamageSource {
	public static DamageSource acid=new DamageSource("acid");
}
